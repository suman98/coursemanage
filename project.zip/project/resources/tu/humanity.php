<?php
include('index.php');
?>


<html>
<body>

<h4>Introduction</h4>
<p>The Faculty of Humanities and Social Sciences (FoHSS) aims at producing specialized human resources in the area of humanities, social science, and computer applications. In terms of subjects offered and the number of faculty it is the largest faculties. There are 30 constituent campuses along with more than 300 affiliated colleges under this faculty. FoHSS provides affiliation based on the following categories:</p>
<ol>
<li>New Affiliations from the</li>
<li>Programme (Subjects) extensions to already affiliated campuses/colleges</li>
<li>Upgrading of the Programmes (subjects) to already affiliated campuses/ colleges</li>
</ol>
<p>This faculty has also been running programmes like International Relation and Diplomacy (IRD), Crisis Management Studies (CMS) and Masters of Social work (MSW). Sports Science is going to be introduced in the coming  session.  Three new Master&#8217;s programmes such as Tourism and Hospitality (TH), Development Studies (DS) and Folklore Studies are under preparation.</p>
<h4>Academic Calendar</h4>
<p>The faculty runs its masters programmes at the central departments in semester systems while other constituent and affiliated colleges run the master programmes under annual system.</p>
<p>Bachelor degree programmes also follow annual system. The Faculty has a policy to upgrade the Bachelor&#8217;s programmes to 4 years. In the initial</p>
<p>Programmes of FoHSS</p>
<p>The Programmes offered by the faculty are as follows:</p>
<ol>
<li>Bachelor’s Level</li>
<li>Post Graduate Diploma (PGD)</li>
</ol>
<ul>
<li>Master’s Level</li>
</ul>
<ol>
<li>Phil. and</li>
<li>D.</li>
</ol>
<p>New Master&#8217;s Programmes of the Faculty:</p>
<ol>
<li>International Relation &amp; Diplomacy (IRD)</li>
<li>Crisis Management Studies (CMS),</li>
</ol>
<ul>
<li>Master of Social Work, iv) Sports Science</li>
</ul>
<p><em>(The new Programmes are designed and run in the semester system)</em></p>
<p><em> </em>New Master Programmes:</p>
<ol>
<li>Tourism and Hospitality (TH)</li>
<li>Development Studies</li>
</ol>
<ul>
<li>Folklore Studies</li>
</ul>
<ol>
<li>Sports Science</li>
</ol>
<p>New Bachelors’ Programme:</p>
<p>Computer Application (BCA) will be offered from the new academic session.</p>
<p>Proposed Programmes:</p>
<ol>
<li>Fashion Designing</li>
<li>Good Governance and Leadership Development</li>
</ol>
<ul>
<li>Social Entrepreneurship</li>
</ul>
<p>phase, Psychology, Social Work and Journalism will be upgraded to 4 years programmes.</p>
<p>The faculty also offers research methodology courses and provides supervision for full-time study leading to the Ph.D. degree, special one-year postgraduate courses in Women’s Studies, Library Science, and Counseling Psychology. The faculty has been publishing half-yearly research journal, <em>Journal of Humanities and Social Sciences</em>. Recently, it has updated its research manual for Ph.D. research and it is available to Ph.D. scholars.</p>
<p>FoHSS conducts 5 to 7 day seminars/workshops in different regions every year. The Faculty has prepared a research profile of awarded Ph.Ds until 2014. The Faculty is also working towards offering a course-based Ph.D. Long term and short term strategic plans of the Faculty have been identified in its five year strategic plan, and policy measures are being rectified to upgrade the teaching/learning and research status.</p>
<p>Other Details</p>
<ul>
<li>The Office of the Dean offers educational and academic support to the central departments, constituent and affiliated colleges for the subjects introduced at various levels in accordance with TU</li>
<li>It forms and supervises Faculty Board, Standing Committees and Subject Committees for different</li>
<li>It takes necessary steps and procedures to evaluate the capacity, and other requirements of the constituent campuses or affiliated colleges to add new subject(s) and</li>
<li>The Faculty runs Phil. Programmes in Economics, English, Population Studies, Nepali, Sociology and Anthropology.</li>
<li>Around 30 to 35 D. candidates receive their Ph.D. degree annually in different disciplines from this faculty.</li>
<li>It conducts D. Programmes in coordination with the concerned central departments and the subject specialists.</li>
</ul>
</body>
</html>