<?php
include('index.php');
?>
<html>
<body>


<p>The Faculty of Management (FoM), Tribhuvan University has its ultimate objective of educating students for professional pursuits in business, industry, and government. It is further dedicated to enhancing the knowledge and understanding of business and public administration. In this pursuit, FoM aims to develop networking with management institutes in the country and abroad to exchange new knowledge, technology and methods  of higher level efficiency in management of business and public entities. It also aims continuously to innovate and promote cost effective, socially relevant, modern technology-based management educational programmes in Nepal.</p>
<p>Master of Travel and Tourism Management (MTTM), Master of Hospitality Management (MHM), Master of Business Management (MBM), Master of Finance and Control (MFC) and Master of Philosophy (M.Phil) Programme. The FoM also offers doctoral Programme in management leading to a degree of Doctor of Philosophy (Ph.D).The FoM offers instruction to Bachelor of Business Studies (BBS), Bachelor of Business Administration   (BBA),   Bachelor   of   Travel and Tourism Management   (BTTM),   Bachelor of Hotel Management (BHM), Bachelor of Information Management (BIM), Bachelor of Business Management (BBM), Bachelor of Public Administration (BPA),  Post  Graduate  Diploma in Police Science (PGDPS), Master of Business Studies (MBS), Master of Business Administration (MBA), Master of Public Administration (MPA),</p>
<h4><strong>Goals of FoM</strong></h4>
<p>Each academic programme in operation under FoM, has its own specific objectives. They are:</p>
<ul>
<li>to prepare middle and top level professional managers capable of handling business in dynamic global</li>
<li>to produce socially responsible and creative entrepreneurs capable of promoting business and industry for the socio-economic development of Nepal,</li>
<li>to conduct research and management development programmes for enhancing the knowledge and skill base of academics and practicing managers,</li>
<li>to innovate and promote management programmes catering to the various social and economic sectors of Nepal,</li>
</ul>
<ul>
<li>to establish linkages with leading universities and management institutes abroad and collaborate with them in programme development and implementation, and</li>
<li>to develop managers for public sector with competency in public policy management and</li>
</ul>
<p><strong>Faculty Board</strong></p>
<p>As an academic entity FoM has a Faculty Board (FB) of its own. Faculty Board of FoM is entrusted with the tasks of designing, enhancing and approving different academic programmes as per society&#8217;s needs. Besides, FB is actively involved in devising modalities of teaching/learning and research activities in campuses under the Faculty. At present, FB consists of 30 members including the chairperson and member secretary. The Standing Committee of the Faculty Board has also been designed to act regularly and deal with routine issues as and when required.</p>
<p><strong>Subject Committees</strong></p>
<p>To look into the academic matters and activities regularly in terms of developing and updating curriculum as per the needs, there are ten Subject Committees with their defined areas. The subject committees are also involved in organizing seminars and workshops to  disseminate  new ideas, knowledge and pedagogies in order to make teaching learning meaningful. The following are the subject committees in operation under the faculty.</p>
<ol>
<li>General Management</li>
<li>Marketing Management</li>
<li>Finance</li>
<li>Accountancy</li>
<li>Management Science</li>
<li>Sectoral Management</li>
<li>Business Economics</li>
<li>Business Administration</li>
<li>Public Administration</li>
<li>Travel, Tourism and Hospitality Management</li>
</ol>
<h4><strong>Research  Committee</strong></h4>
<p>To conduct research activities in the areas of management and public administration and thereupon contribute for research-based teaching/ learning process and enhance the quality of education, Research Committee has been functional under the Faculty of Management. The research committee comprises of ten members including the chairperson and the member secretary.</p>
<p><strong>International Relations</strong></p>
<p>FoM has a rich history of exchange programmes and collaborative arrangements with leading industrial and business houses, management institutions, professional associations, and Universities around the world.</p>
<p>FoM is a permanent member of Association of Management Development Institutions in South Asia (AMDISA) and involved in collaborative efforts regularly.</p>
<p>The Faculty has signed Memorandum of Understanding with Department of Administration and Organization Theory, University of Bergen (UoB), Norway and working towards national, regional and international cooperation in public affairs management and research alike.</p>
<p>In line with maintaining academic and professional link, the Faculty is sponsoring two candidates each year to participate in Programme for the Development of Management Faculties (PDMF) of Indian Institute of Management, Ahmadabad (IIMA). Corollary to the above, FoM is also sponsoring candidates to participate in national and international seminars and similar other academic events, regularly.</p>
<p>Inviting scholars and professors from SAARC region for guest lecturers and conduction of Viva- voce examination of PhD candidates thereupon strengthening the  bondage  of  relationships  with academics from reputed universities has also been a regular phenomenon of the Faculty.</p>
<p>To meet the requirements of the human resource market, FoM has completed the revision, of the</p>
<p style="text-align: justify;">P<strong>rogrammes of FoM</strong></p>
<p>The faculty runs both general as well as professional academic Programmes. The Programmes offered by the faculty are as follows:</p>
<ul>
<li>Bachelor’s Level</li>
<li>Post Graduate Diploma Level</li>
<li>Master’s Level</li>
<li>Phil</li>
<li>Ph.D</li>
</ul>
<p>New Degree established</p>
<ul>
<li>MPS (Masters of Police Science)</li>
<li>Professional  MBA   (Masters   of   Business Administration)</li>
<li>MBA (Information Technology)</li>
<li>MBA (Health Care Management)</li>
</ul>
<p>Bachelor’s Programme Under Annual System</p>
<ul>
<li><strong>Bachelor of Business Studies (BBS)</strong></li>
</ul>
<p>Areas of Specialization:</p>
<ul>
<li>General Management</li>
<li>Marketing Management</li>
<li>Finance</li>
<li>Accountancy</li>
<li>Management Science</li>
</ul>
<p>Bachelor’s Programmes Under Semester System</p>
<ul>
<li><strong>Bachelor of Business Administration (BBA)</strong></li>
</ul>
<p>Areas of Specialization:</p>
<ul>
<li>Banking and Finance</li>
<li>Industrial Management</li>
<li>Marketing Management</li>
<li>Travel and Tourism Management</li>
<li>Management Information System</li>
</ul>
<p>Bachelor of Information Management (BIM)</p>
<p>Bachelor  of  Travel  and  Tourism  Management (BTTM)</p>
<p>Bachelor of Hotel Management (BHM) Bachelor of Business Management (BBM) Bachelor of Public Administration (BPA)</p>
<p>Post Graduate Programme in Public Administration Under Semester System</p>
<p>Post Graduate Diploma in Police Sciences (PGDPS)</p>
<p>Masters’ Programme Under Semester System</p>
<ul>
<li>Master of Business Administration (MBA)</li>
<li>Master of Travel and Tourism Management (MTTM)</li>
<li>Master of Hospitality Management (MHM)</li>
<li>Master of finance Control (MFC)</li>
<li>Master of Business Management (MBM)</li>
<li>MBA in Global Leadership Development</li>
<li>Master of Business Studies (MBS)</li>
</ul>
<p>Areas of Specialization:</p>
<ul>
<li>General Management</li>
<li>Marketing Management</li>
<li>Finance</li>
<li>Accountancy</li>
<li>Management Science</li>
</ul>
<p>Master of Public Administration (MPA)</p>
<p>Areas of Specialization:</p>
<ul>
<li>Development Management</li>
<li>Human Resource Management</li>
<li>Local Governance and Development</li>
<li>Civil Society Governance</li>
<li>Public Policy</li>
</ul>
<p>Master of Philosophy in Management (M.Phil.)</p>
<p>Areas of Specialization:</p>
<ul>
<li>Management</li>
<li>Finance</li>
<li>Accountancy</li>
</ul>
<p>M.Phil in Public Administration</p>
<p>Areas of Specialization:</p>
<p><strong><em> </em></strong>Public Policy</p>
<ul>
<li>Human Resource Management</li>
<li>Local Governance and NGO Management</li>
</ul>
</body>
</html>w