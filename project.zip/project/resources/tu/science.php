
<?php
include('index.php');
?>


<ol>
<li>Programmes of IoST</li><br>

a) Bachelor’s Level (B.Sc. Programmes)
Annual System Programmes <br/>

B.Sc. 4 year (running from 2069 batch)<br/>
B.Tech. (Food)<br/>
B.Sc. (Nutrition and Dietetics)<br/><br/>
Semester System Programmes<br/>

B.Sc. CSIT (Computer Science and Information Technology)<br/>
B.Sc.TTM (Tea Technology and Management)<br/>
B.Mathematical Science<br/>
B.Sc. Horticulture and Floriculture Management<br/><br/><br/>
b) Master Level (M.Sc.) Programmes<br/>
Annual System Programmes<br/>

M.Tech – Food Technology<br/><br/>
Semester System Programmes<br/>

M.Sc. CSIT<br/>
M.Sc. Math<br/>
M.Sc. Microbiology<br/>
M.Sc. Environmental Science<br/>
M.Sc. Statistics<br/>
M.Sc. Bio-Technology<br/>
M.Sc. Biodiversity and Environmental Management<br/>
M.Sc. Physics, Chemistry, Zoology, Botany, Geology, Hydrology & Meteorology<br/>
M.Sc. in Engineering Geology<br/>
M.Mathematical Science<br/>
<br/><br/>
<li>Programmmes of IOE(Engineerings)</li><br/>
BE in Computer<br/>
BE in Electronics<br/>
BE in Cvil <br/>
BE in Mechanics<br/>
BE in Arthicture<br/>
<br/><br/>
<li>Programmes of IOM(Medical)</li>
MBBS<br/>
BDS<br/>
BMLT<br/>
Bsc.Nurshing<br/>
</ol>

</body>
</html>
