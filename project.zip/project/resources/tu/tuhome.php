<?php
include('index.php');
?>


<html>

<body>

<p>
<div id="paragraph">
TU marked its golden jubilee in the year 2009 organizing various programmes. In the 54th year of its establishment, the university family remains committed and dedicated to making it a source and centre of quality education to set up a culture of learning in the country and to promote the notion of national and global peace and harmony.
<br/><br/>

 

Since its inception, TU, the state owned university, has expanded its programmes in different disciplines. There are five technical institutes and four general faculties. TU offers 50 courses for the technical proficiency certificate level. 1079 courses at Bachelor’s level and 1000 courses at Master’s level. It also offers Ph.D. degree in different disciplines both at the Technical Institutes and Faculties.
<br/>
<br/>
 

TU ran its programmes only through its constituent campuses prior to 1980. As the number of the students willing to acquire higher education was increasing day by day, it was not possible for the university to accommodate all the students in the constituent campuses. This situation led to the establishment of colleges in the private sector.  From 1979 –80, TU started providing affiliation to private colleges to conduct various programmes at different levels. 931 private colleges spread all over the country have so far received affiliations from TU.

 <br/><br/>

In the current academic session (2013-2014) altogether 6,04,437 students have been enrolled at various levels of TU academic programmes. 2,73,349 (45.22%) students study in its 60 constituent campuses including 38 central departments, while 3,31,088 (54.78%) students study in 931 affiliated colleges. It clearly reveals that affiliated colleges do have more students than the constituent campuses.
<br/><br/>
 

TU has 7966 teaching faculty and 7230 non-teaching staff including the support staff in its constituent campuses. The total number of employees is 15196 including 124 new post of the Manmohan Cardiothorasic Centre.
<br/><br/>
</div>
</p>
</body>
</html>