<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--
Template Name: Education Time
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> University Course</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="../resources/assets/layout/styles/layout.css" type="text/css" />
<script type="text/javascript" src="../resources/assets/layout/scripts/jquery.min.js"></script>
<!-- liteAccordion is Homepage Only -->
<link rel="stylesheet" href="../resources/assets/layout/scripts/liteaccordion-v2.2/css/liteaccordion.css" type="text/css" />
</head>
<body id="top">
<div class="wrapper row1">
  <div id="header" class="clear">
    <div class="fl_left">
      <h1><a href="home.php">Nepal University Course</a></h1>
      <p>WELCOME</p>
    </div>
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper row2">
  <div id="topnav">
    <ul>
      <li class="active"><a href="../public/home.php">Homepage</a></li>
      <li><a href="pages/style-demo.html">About us</a></li>
      <li><a href="#">University</a>
        <ul>
          <li><a href="../resources/tu/tuhome.php">Trivuvan University</a></li>
        </ul>
      </li>
      <li><a href="../routes/searchcourse.html">Search records</a></li>
      <li><a href="../routes/decide.html">Add record</a></li>
      <li><a href="../routes/delete.html">Delete record</a></li>
      <li><a href="../routes/fee.html">Fee Payment</a></li>
    </ul>

    <div  class="clear"></div>
  </div>
</div>
<!-- ####################################################################################################### -->
</body>
</html>
