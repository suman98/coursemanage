<?php
$con=mysqli_connect("localhost","root","","project");
session_start();
$sid=$_POST['sid'];
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$check=("SELECT * from account where email='$email'");
$contact=$_POST['contact'];
$date=$_POST['dd'];
$month=$_POST['mm'];
$year=$_POST['year'];
$level=$_POST['level'];
if($fname==NULL)
{
    echo "error";
   exit(1);
}
$level=$_POST['level'];
if(isset($_POST['gender']))
{
    $operation1=$_POST['gender'];
    switch ($operation1) {
        case 'male':
            $gender="male";
            break;
        
        case 'female':
            $gender="female";
            break;
    }
}

if(isset($_POST['education']))
{
    $operation2=$_POST['education'];
    switch ($operation2) {
        case 'Bsc.Csit':
            $education="Bsc.Csit";
            break;
        
        case "BBS":
            $education="BBS";
            break;
    }
}
$result=$con->query("SELECT * FROM  student WHERE sid='$sid' ");
$check=mysqli_num_rows($result);
if($check>0){
    echo "sorry please select different ID";
}
else{
$sql=("INSERT INTO student(sid,first,last,contact,gender,course,email,date,month,year,level) VALUES('$sid','$fname','$lname','$contact','$gender','$education','$email','$date','$month','$year','$level')");
mysqli_query($con,$sql);
$sql1=("INSERT INTO fee(sid) VALUES('$sid')");
mysqli_query($con,$sql1);
echo "Record added";
}
?>