
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Seach course</title>
  
  <link rel="stylesheet" href="../public/css/form1.css">

  <link rel='stylesheet prefetch' href='../public/css/form2.css'>

      <link rel="stylesheet" href="../public/css/form3.css">
</head>

<body>
  
<div class="container">
  <form method="post" action="feeupdate.php">
    <div class="row">
      <h4>AMOUNT</h4>
      <div class="input-group input-group-icon">
        <input type="text" placeholder="ENTER AMOUNT" name='amount'>
        <div class="input-icon"><i class="fa fa-user"></i></div>
      </div>
      </div>
      <br/>
      <input type="submit" name="submit" value="UPDATE">
      </div>
      </form>
      <br/>
      <a href="../public/home.php"><button type="button" >HOME</button></a>
      <?php
      $con=mysqli_connect("localhost","root","","project");
      session_start();
      $temp=$_POST['amount'];
      $total=$_SESSION['fee'];
      $totalfee=$temp+$total;
      $id=$_SESSION['id'];
      echo "id is ".$id;
      echo "fee is".$total;
      $sql=("UPDATE fee 
                SET total='$totalfee'
                WHERE sid='$id'");
mysqli_query($con,$sql);
echo "Record added";
?>
</body>
</html>
