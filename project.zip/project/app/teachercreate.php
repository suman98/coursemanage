<?php
$con=mysqli_connect("localhost","root","","project");
session_start();
$tid=$_POST['tid'];
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$check=("SELECT * from account where email='$email'");
$contact=$_POST['contact'];
$date=$_POST['dd'];
$month=$_POST['mm'];
$year=$_POST['year'];
$salary=$_POST['salary'];
$subject=$_POST['subject'];
if($fname==NULL)
{
    echo "error";
   exit(1);
}
if(isset($_POST['gender']))
{
    $operation1=$_POST['gender'];
    switch ($operation1) {
        case 'male':
            $gender="male";
            break;
        
        case 'female':
            $gender="female";
            break;
    }
}

if(isset($_POST['education']))
{
    $operation2=$_POST['education'];
    switch ($operation2) {
        case 'Bsc.Csit':
            $faculty="Bsc.Csit";
            break;
        
        case "BBS":
            $faculty="BBS";
            break;
    }
}
if(isset($_POST['work']))
{
    $operation3=$_POST['work'];
    switch ($operation3) {
        case 'full':
            $work="FULL TIME";
            break;
        
        case "part":
            $work="PART TIME";
            break;
    }
}
$result=$con->query("SELECT * FROM  teacher_rec WHERE tid='$tid' ");
$check=mysqli_num_rows($result);
if($check>0){
    echo "sorry please choose different id";
    exit(1);
}
$sql=("INSERT INTO teacher_rec(tid,first,last,contact,gender,course,salary,email,date,month,year,work) VALUES('$tid','$fname','$lname','$contact','$gender','$faculty','$salary','$email','$date','$month','$year','$work')");
mysqli_query($con,$sql);
$sql1=("INSERT INTO course(tid,cname,faculty) VALUES('$tid','$subject','$faculty')");
mysqli_query($con,$sql1);
echo "Record added";
?>