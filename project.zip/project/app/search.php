<html>
<head>
Result:
<title>
search result
</title>
</head>
<style>
body{
	font-size: 25px;

}
head{
	text-align: center;

}
</style>
<body>
<?php

ini_set("display_errors", 0);

if(isset($_POST['submit']))
{
$con=mysqli_connect("localhost","root","","project");
session_start();

if(isset($_POST['u']))
{
	$operation=$_POST['u'];
	switch ($operation) {
		case 'teacher':
			$type="teacher_rec";
			goto teacher;
			break;

		case 'student':
			$type="student";
			goto student;
			break;
	}
}
else {
	echo "please select any option to search";
	exit(1);
}
student:
$name=$_POST['name'];
$result=$con->query("SELECT * FROM  $type WHERE first='$name' ");

$check=mysqli_num_rows($result);
if($check>0){
while($rows=$result->fetch_assoc())
{
	echo "<p>";
	echo "first Name: " .$rows['first']."<br>";
	echo "last Name: " .$rows['last']."<br>";
	echo "Faculty: ".$rows['course']."<br>";
	echo "level :".$rows['level']." year<br>";
	echo "gender: ".$rows['gender']."<br>";
}
}
else {
	echo "sory no such student available in ".$type;
}
exit(1);
teacher:
$name=$_POST['name'];
$result=$con->query("SELECT * 
						FROM  teacher_rec,course
						WHERE first='$name' AND teacher_rec.tid=course.tid ");

$check=mysqli_num_rows($result);
if($check>0){
while($rows=$result->fetch_assoc())
{
	echo "<p>";
	echo "first Name: " .$rows['first']."<br>";
	echo "last Name: " .$rows['last']."<br>";
	echo "Faculty: ".$rows['faculty']."<br>";
	echo "subject tought :".$rows['cname']." <br>";
	echo "gender: ".$rows['gender']."<br>";
}
}
else{
	echo "NO such teacher found";
}
}
?>
</body>
</html>
